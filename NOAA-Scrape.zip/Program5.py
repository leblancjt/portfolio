# Author: John LeBlanc
# Date: 03/06/2020
#
# https://matplotlib.org/3.1.3/api/_as_gen/matplotlib.pyplot.html
# https://www.ncdc.noaa.gov/cdo-web/webservices/v2
# 
# Extracted Data from multiple years and every station. Calculated an average, and     # created a bar graph to dispay the data.

import requests
import json
import time
from urllib.parse import urljoin
import matplotlib.pyplot as plt
import numpy as np

with open('noaa-token.txt', 'r') as fp:
    token = fp.read().strip()

headers = {
    'token': token
}

base = 'https://www.ncdc.noaa.gov/cdo-web/api/v2/'
endpoint = 'data'
url = urljoin(base, endpoint)
datasetid = 'GSOY'
datatypeid = 'SNOW'
dates = ['2010-01-01', '2011-01-01', '2012-01-01', '2013-01-01', '2014-01-01', '2015-01-01', '2016-01-01', '2017-01-01', '2018-01-01', '2019-01-01', '2020-01-01']
locationid = 'FIPS:25'
units = 'standard'
limit = 1000
SNOW = [[] for i in range(len(dates) - 1)]
SNOWAVG = []

for i in range(len(dates) - 1):
    params = {
        'datasetid' : datasetid,
        'datatypeid' : datatypeid,
        'locationid' : locationid,
        'startdate' : dates[i],
        'enddate' : dates[i + 1],
        'units' : units,
        'limit' : limit
    }
    response = requests.get(url, headers = headers, params = params)
    data = json.loads(response.text)['results']
    time.sleep(0.5)
    
    for s in range(len(data)):
        SNOW[i].append(data[s]['value'])
        
    SNOWAVG.append(round(sum(SNOW[i]) / len(SNOW[i]), 2))

N = len(SNOWAVG)

ind = np.arange(N)
width = 0.35

p = plt.bar(ind, SNOWAVG, width)

plt.ylabel('Average Snowfall (inches)')
plt.title('Average Annual Snowfall in Massachusetts from 2010 - 2019')
plt.xticks(ind, ('2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017', '2018', '2019'))
plt.yticks(np.arange(0, 81, 10))
plt.show()